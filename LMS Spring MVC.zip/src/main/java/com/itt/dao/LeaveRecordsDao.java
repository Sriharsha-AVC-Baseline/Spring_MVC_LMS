package com.itt.dao;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

@Repository("leaveRecordDao")
@Transactional
public class LeaveRecordsDao {

}
