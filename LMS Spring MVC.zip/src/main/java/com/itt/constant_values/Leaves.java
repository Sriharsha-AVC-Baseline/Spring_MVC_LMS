package com.itt.constant_values;

public class Leaves {
	
	public static final int CASUAL_LEAVE = 10;
	
	public static final int EARNED_LEAVE = 15;
	
	public static final int DUTY_LEAVE = 0;
	
	public static final int SICK_LEAVE = 12;
	
	public static final int	MATERNITY_LEAVE = 120;
	
	public static final int PARENTAL_LEAVE = 7;
	
	public static final int LEAVE_WITHOUT_PAY = 180;
	
}
