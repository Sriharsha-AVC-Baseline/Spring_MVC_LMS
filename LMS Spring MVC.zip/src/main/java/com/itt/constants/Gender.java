package com.itt.constants;

public enum Gender {
	
	MALE,FEMALE,OTHERS

}
