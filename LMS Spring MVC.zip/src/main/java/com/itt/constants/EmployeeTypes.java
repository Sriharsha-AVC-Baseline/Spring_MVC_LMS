package com.itt.constants;

public enum EmployeeTypes {
	
	MANAGER,LEAD,EXECUTIVE;

}
