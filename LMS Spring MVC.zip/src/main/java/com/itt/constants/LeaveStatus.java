package com.itt.constants;

public enum LeaveStatus {

	PENDING,CANCELLED,APPROVED,APPROVED_BY_LEAD,REJECTED,REVOKED,AVAILED
}
